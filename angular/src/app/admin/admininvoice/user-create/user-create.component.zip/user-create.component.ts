import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, NavigationStart, Event, NavigationEnd } from '@angular/router';
import { UserRestService } from '../user-rest.service';
import { FormGroup, FormControlName, Validators, FormControl } from '@angular/forms';
import { Subscription } from 'rxjs'
import { debounceTime, distinctUntilChanged } from 'rxjs/operators'
import jsPDF from 'jspdf'
import { tap } from 'rxjs/operators';
import html2canvas from 'html2canvas';
@Component({
  selector: 'app-user-create',
  templateUrl: './user-create.component.html',
  styleUrls: ['./user-create.component.scss']
})
export class UserCreateComponent implements OnInit {

  serverErrors = [];
  users: Array<object> = [];
  disableBtn: boolean = false;
  points = [];
  total: number;
  signatureImage;
  registerForm: FormGroup;
  values: any;
  display: boolean = false;
  displayModal: boolean;
  displayBasic: boolean;
  displayDataBasic: boolean;
  displayMaximizable: boolean;
  displayPosition: boolean;
  timeout;
  routerChanged = false;

  constructor(private route: ActivatedRoute, private userRest: UserRestService, private router: Router) {
}

  generatePDF() {
    var data = document.getElementById('tablecontent');
    console.log(data)
    html2canvas(data).then(canvas => {
      var imgWidth = 500;
      var imgHeight = canvas.height * imgWidth / canvas.width;
      const contentDataURL = canvas.toDataURL('image/png')
      const pdf = new jsPDF();
      var position = 0;
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)
      pdf.save('invoice-payment.pdf');
    });
  }
  showBasicDialog() {

    console.log()

  }

  showImage(data) {
    this.signatureImage = data;
    this.displayBasic = true;
    console.log(this.signatureImage)
  }
  ngOnInit() {

    this.registerForm = new FormGroup({
      'invoiceNumber': new FormControl("WMZ001", [Validators.required]),
      'amount': new FormControl(null, [Validators.required]),
      'rate': new FormControl("", [Validators.required]),
      'hours': new FormControl(null, [Validators.required]),
      'services': new FormControl("", [Validators.required]),
      'printName': new FormControl("", [Validators.required]),
      'date': new FormControl("", [Validators.required]),
    })

    this.userRest.getCurentUser().subscribe(
      (response) => {
        console.log(this.users = response.user);
        this.registerForm.patchValue({ rate: response.user.rate })
      },
      (error) => { console.log(error) }
    );
    this.registerForm.valueChanges.pipe(

      distinctUntilChanged(this.isSame)
    ).subscribe(values => {
      console.log(values)
      const { rate, hours } = values;
      this.registerForm.patchValue(
        {
          amount: (rate * hours)
        }
      )
    })

  }

  get invoiceNumber() { return this.registerForm.get('invoiceNumber'); }
  get amount() { return this.registerForm.get('amount'); }
  get rate() { return this.registerForm.get('rate'); }
  get hours() { return this.registerForm.get('hours'); }
  get services() { return this.registerForm.get('services'); }
  get printName() { return this.registerForm.get('printName'); }
  get date() { return this.registerForm.get('date'); }

  isSame(prev, next) {
    return (prev.rate === next.rate)
      && (prev.hours === next.hours);
  }
  registerUser() {

    console.log(this.registerForm);
    this.userRest.storePayment(this.registerForm).subscribe(
      response => {
        console.log(response),
          this.router.navigate(['payments/list'])
      },
      error => {
        this.serverErrors = error.error.errors
      }
    );
  }

}
